Regression Result Files
===


This folder includes the regression result Files.

- ./
  - country_discipline_VIF.xlsx  ## vif test for country and discipline pairs
  - NBGLM_DIS.xlsx  ## regression result across disciplines
  - NBGLM_DIS_VIF.xlsx ## vif test for each discipline
  - NM_IM.xlsx ## regression result for table 9, for details see files in folder ./IC/
  - number_obs_country_discipline.xlsx ## number of records for each country and discipline
- ./countries_summary/ ## regression summary for each country
  - IC_BR.xlsx
  - IC_CA.xlsx
  - ...
- ./Discipline/ ## raw regression summary for each discipline
  - AGR.txt
  - BIO.txt
  - ...
- ./IC/ ## detail regression result for table 9
  - IC_DomesticIM_mark.xlsx
  - IC_DomesticNM_mark.xlsx
  - ./BR/ ## raw regression summary
    - AGR.txt
    - ...
  - ./CA/
    - AGR.txt
    - ...
